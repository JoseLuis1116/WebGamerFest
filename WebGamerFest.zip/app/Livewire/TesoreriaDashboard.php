<?php

namespace App\Livewire;

use Livewire\Component;

class TesoreriaDashboard extends Component
{
    public function render()
    {
        return view('livewire.tesoreria-dashboard');
    }
}
