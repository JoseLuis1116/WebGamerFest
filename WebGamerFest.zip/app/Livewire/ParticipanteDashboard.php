<?php

namespace App\Livewire;

use Livewire\Component;

class ParticipanteDashboard extends Component
{
    public function render()
    {
        return view('livewire.participante-dashboard');
    }
}
