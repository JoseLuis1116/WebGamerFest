<?php

namespace App\Livewire;

use Livewire\Component;

class CoordinadorDashboard extends Component
{
    public function render()
    {
        return view('livewire.coordinador-dashboard');
    }
}
