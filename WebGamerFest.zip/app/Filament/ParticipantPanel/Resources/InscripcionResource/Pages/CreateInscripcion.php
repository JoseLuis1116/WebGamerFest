<?php

namespace App\Filament\ParticipantPanel\Resources\InscripcionResource\Pages;

use App\Filament\ParticipantPanel\Resources\InscripcionResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateInscripcion extends CreateRecord
{
    protected static string $resource = InscripcionResource::class;
}
