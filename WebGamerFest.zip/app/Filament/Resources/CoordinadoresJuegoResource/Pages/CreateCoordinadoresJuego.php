<?php

namespace App\Filament\Resources\CoordinadoresJuegoResource\Pages;

use App\Filament\Resources\CoordinadoresJuegoResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCoordinadoresJuego extends CreateRecord
{
    protected static string $resource = CoordinadoresJuegoResource::class;
}
